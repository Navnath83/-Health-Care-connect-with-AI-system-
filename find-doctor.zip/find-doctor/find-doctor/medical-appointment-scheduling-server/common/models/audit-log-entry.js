module.exports = function(AuditLogEntry) {

};
