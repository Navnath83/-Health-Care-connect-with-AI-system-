'use strict';

module.exports = function(Notificationtransport) {

};
