# medical-appointment-scheduling-server

## Local setup
Clone this repository and run
```shell
$ npm install
$ npm start
```
with a postgres database set up according to the [`datasources.json`](https://github.com/sebastianhaas/medical-appointment-scheduling-server/blob/master/server/datasources.json) config file running, start the server using
```shell
$ npm start
```
