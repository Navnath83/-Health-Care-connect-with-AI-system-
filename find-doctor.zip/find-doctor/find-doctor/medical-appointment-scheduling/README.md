# Medical Appointment Scheduling

[![Greenkeeper badge](https://badges.greenkeeper.io/sebastianhaas/medical-appointment-scheduling.svg)](https://greenkeeper.io/)
[![Build Status](https://travis-ci.org/sebastianhaas/medical-appointment-scheduling.svg?branch=master)](https://travis-ci.org/sebastianhaas/medical-appointment-scheduling)
[![Dependency Status](https://david-dm.org/sebastianhaas/medical-appointment-scheduling.svg)](https://david-dm.org/sebastianhaas/medical-appointment-scheduling)
[![Join the chat at https://gitter.im/sebastianhaas/medical-appointment-scheduling](https://badges.gitter.im/sebastianhaas/medical-appointment-scheduling.svg)](https://gitter.im/sebastianhaas/medical-appointment-scheduling?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Concept showcase for "Design of a Web-Based Appointment Scheduling System for Small and Medium-Sized Medical Facilities".

## How to deploy
This application can be easily deployed to Heroku. tbd

## How to run locally
After checkout, run:
```
$ nvm use 6.10.0
$ npm install
$ npm start
```
This requires node >=4 together with npm to be installed. This repository doesn't contain any backend, you need to have an instance of [medical-appointment-scheduling-server](https://github.com/sebastianhaas/medical-appointment-scheduling-server) running.

### Unit tests
```
$ npm run test
```

## Technology stack
### Core technologies
* [Angular 2](https://angular.io/)
* [Angular Material](https://material.angular.io/)
* [SASS](http://sass-lang.com/)

### Bundling and packaging
* [webpack](https://webpack.github.io/)
* [npm](http://npmjs.com/)

### Testing
* [Karma](https://karma-runner.github.io/1.0/index.html)
* [Jasmine](http://jasmine.github.io/)
* [Protractor](http://www.protractortest.org/)
* [Selenium](http://docs.seleniumhq.org/)

### Code style
* [codelyzer](https://github.com/mgechev/codelyzer)
* [tslint](https://palantir.github.io/tslint/)

### Documentation
* [Typedoc](https://github.com/TypeStrong/typedoc)

### Internationalization
* [Angular 2's `ng-xi18n` tool](https://angular.io/docs/ts/latest/cookbook/i18n.html#!#ng-xi18n)
* [POEditor](https://poeditor.com/)
